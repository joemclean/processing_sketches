import imported_module_with_pvector as m

m.sayok()
exit()
