text(u"ö", 0, 20)
print(u'OK')
exit()
