start = millis()
delay(2)
assert millis() > 2
print 'OK'
exit()
