import jycessing.primitives.PrimitiveFloat as PF
p = PF(66.0)
p.value += .7
print(p)
exit()